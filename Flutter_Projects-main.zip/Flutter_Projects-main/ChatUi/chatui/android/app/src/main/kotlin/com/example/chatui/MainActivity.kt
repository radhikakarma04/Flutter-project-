package com.example.chatui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
